package com.appsdeveloperblog.photoapp.OrdersWebOAuthClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersWebOAuthClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
